import xml.etree.ElementTree as ET
import os
from math import ceil
import sys
from tqdm import *
from PIL import Image
import cv2
from multiprocessing import Process,Pool


def find(folder_path,extensions,local=False):
    '''
    查找某目录下特定后缀的文件，返回文件的绝对路径
    # params: folder_path
    # params: extension, # extensions = ['.jpeg', '.jpg', '.png', '.bmp']
    # params: local  默认True, 只查找当前目录下的文件
    '''
    images = []
    if local:
        filelist = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path,f))]
        for file in filelist:
            if file.lower().endswith(tuple(extensions)):
                    relatviePath = os.path.join(folder_path, file)
                    path = os.path.abspath(relatviePath)
                    images.append(path)
        images.sort(key=lambda x: x.lower())
    else:
        ##遍历文件夹下的所有文件
        for root, dirs, files in os.walk(folder_path,topdown=False):
#             print('root:',root)
            for file in files:
                if file.lower().endswith(tuple(extensions)):
                    # images.append(file)
                    relatviePath = os.path.join(root, file)
                    path = os.path.abspath(relatviePath)
                    images.append(path)
        images.sort(key=lambda x: x.lower())
    return images



def convert(size, box):
    dw = 1./(size[0])
    dh = 1./(size[1])
    x = (box[0] + box[1])/2.0 - 1
    y = (box[2] + box[3])/2.0 - 1
    w = box[1] - box[0]
    h = box[3] - box[2]
    x = x*dw
    w = w*dw
    y = y*dh
    h = h*dh
    return (x,y,w,h)

def check(file):
    if os.path.exists(file):
        return open(file,"a")
    else:
        return open(file,"w")

def collect_info(xml_path,image_path,classes):
    extensions = ['.xml']
    xmls = []
    tmp_xmls = find(xml_path, extensions, local=False)
    for xml in tqdm(tmp_xmls):
        tree = ET.parse(xml)
        root = tree.getroot()
        for obj in root.iter('object'):
            name = obj.find('name')
            if name.text in classes:
                xmls.append(xml)
                break
    xmls = {os.path.basename(xml[:-4]): xml for xml in xmls}
    print("xml done!")
    extensions = ['.jpeg', '.jpg', '.png', '.bmp', ".JPG"]
    images = find(image_path, extensions, local=False)
    images = {os.path.basename(image[:-4]): image for image in images}
    # print("img done!")
    return images,xmls

def multiprocessing(run, filelist, process_Num):
    # 多进程
    p = []
    Num=ceil(len(filelist) / process_Num)
    for i in range(0, len(filelist), Num):
        end = i + Num if i + Num < len(filelist) else len(filelist)
        t = Process(target=run, args=(tqdm(filelist[i:end]),))
        t.daemon = True
        t.start()
        p.append(t)
    for t in p:
        t.join()

# def multiprocessing(run, filelist, process_Num):
#     with Pool(process_Num) as p:
#         print(list((tqdm(p.imap(run, filelist), total=len(filelist), desc='当前进度'))))

def write_text_img(images,xmls,max_size=(0,0),scale = 1,mode="train",multiprocess=True,process_Num=10,interpolation=cv2.INTER_CUBIC):
    # 准备数据集文本文件,图像进行resize操作
    assert mode=="train" or mode=="val"
    def run(files):
        for item in files:
            try:
                im = Image.open(images[item])#对于损坏的图片，部分可以被cv正常读取，但是Image会抛出错误
                im = cv2.imread(images[item])
            except:
                print("error for read file {}".format(images[item]))
                ferror.write(images[item])
            if max_size ==(0,0) && scale !=0:
                im = cv2.resize(im, size, fx=scale, fy=scale,interpolation=interpolation)
            elif isinstance(max_size,tuple) :
                im = cv2.resize(im, size, fx=scale, fy=scale, interpolation=interpolation)
            elif isinstance(max_size,int) || isinstance(max_size,float):
                m,n,_=im.shape
                scale = min(max_size/float(m),max_size/float(n))
                im = cv2.resize(im, (0,0), fx=scale, fy=scale, interpolation=interpolation)
            else:
                print("请检查max_size或者scale ")
                exit()
            cv2.imwrite(save_path + "/images/" + item + ".jpg", im)

            fann.write(xmls[item] + '\n')
            fimg.write(save_path + "/images/" + item + ".jpg" + '\n')

                
    if mode == "train":
        fann = check(save_path + "/train_ann.txt")
        fimg = check(save_path + "/train_img.txt")
    elif mode == "val":
        fann = check(save_path + "/val_ann.txt")
        fimg = check(save_path + "/val_img.txt")
        
    ferror = check(save_path + "/error.txt")

    filelist = sorted(list(set(xmls).intersection(set(images))))
    if not os.path.exists(save_path + "/images"):
        os.makedirs(save_path + "/images")
    if multiprocess:
        # 多进程
        multiprocessing(run, filelist, process_Num)
    else:
        run(filelist)
    fann.close()
    fimg.close()
    ferror.close()


def write_labels(mode = "train",multiprocess=True,process_Num=10):
    # 创建lable文件
    def run(filelist):
        for xmlpath in filelist:
            image_id, _ = os.path.splitext(os.path.basename(xmlpath))
            in_file = open(xmlpath[:-1])
            out_file = open(save_path + '/labels/%s.txt' % (image_id), 'w')
            tree = ET.parse(in_file)
            root = tree.getroot()
            size = root.find('size')
            w = int(size.find('width').text)
            h = int(size.find('height').text)

            for obj in root.iter('object'):
                difficult = 1 if obj.find('difficult') == None else obj.find('difficult').text
                cls = None if obj.find('name') == None else obj.find('name').text
                if cls not in classes or int(difficult) == 1:
                    continue
                cls_id = classes.index(cls)
                xmlbox = obj.find('bndbox')
                b = (float(xmlbox.find('xmin').text), float(xmlbox.find('xmax').text), float(xmlbox.find('ymin').text),
                     float(xmlbox.find('ymax').text))
                bb = convert((w, h), b)
                out_file.write(str(cls_id) + " " + " ".join([str(a) for a in bb]) + '\n')

    assert mode == "train" or mode == "val"
    if mode == "train":
        fxmllist = open(save_path + "/train_ann.txt", "r")
    elif mode == "val":
        fxmllist = open(save_path + "/val_ann.txt", "r")
    if not os.path.exists(save_path + "/labels"):
        os.makedirs(save_path + "/labels")
    filelist = fxmllist.readlines()
    if multiprocess:
        multiprocessing(run, filelist, process_Num)
    else:
        run(filelist)
    
    
    
def collect_img_labels(save_path,xml_path,image_path,classes,max_size=( 0, 0),scale = 1,mode="train", multiprocess=True , process_Num=5,interpolation=cv2.INTER_CUBIC):
    '''
        提供文件保存路径、图片路径、xml路径、所需类别名称、缩放大小或者缩放比例
        数据在不同文件夹时可以多次调用,根据实际情况传入不同xml_path和img_path参数
        自动整理数据到保存路径文件夹，形成如下结构目录：
        labels文件记录的是目标框与图像的相对位置关系，与图像本身大小无关，故可不用重新生成xml再生成lables文件
        save_path|
                 |labels|
                 |      |a.txt
                 |      |b.txt
                 |      |c.txt
                 |
                 |images|
                 |      |a.jpg
                 |      |b.jpg
                 |      |c.jpg
                 |
                 |train_ann.txt
                 |train_img.txt
                 |val_ann.txt
                 |val_img.txt
        
        
        参数说明
        save_path：文件保存路径"/home/daniel/ht/data"
        xml_path="/raid/ht/连接金具样本库/train/modify"
        image_path="/raid/ht/连接金具样本库/train/JPEGImages"
        classes = ['dx_gt','gt_jyz','jyz_dx']
        max_size,scale resize后图像的最大大小或者缩放尺度，其中max_size可以是缩放后图像的大小，如（608，406），也可以为单边的最大长度，如1000
        mode 当前数据类型，"train"还是"val"
        multiprocess是否启动多进程，默认为True
        process_Num 线程数
        
    '''
    images,xmls=collect_info(xml_path,image_path,classes)#收集xml和img信息
    if not os.path.exists(save_path ):
        os.makedirs(save_path )
    write_text_img(images,xmls,max_size,scale,mode,multiprocess,process_Num,interpolation)#写入文本信息并resize图片
    write_labels(mode,multiprocess,process_Num)#写入标签信息

if __name__ =="__main__":
    save_path="/raid/data_608"
    classes=["dx_gt","gt_jyz","jyz_dx"]
    max_size=(608,608)#
    for _ in os.listdir(" "):
        xml_path="/raid/data/xml"
        image_path="/raid/data/images"
        collect_img_labels(save_path,xml_path,image_path,classes,max_size=( 0, 0),scale = 1,mode="train", multiprocess=True , process_Num=5,interpolation=cv2.INTER_CUBIC)

