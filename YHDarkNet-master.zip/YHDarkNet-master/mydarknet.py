
'''
注释：
    参考https://blog.csdn.net/leilei18a/article/details/107281540
    由于最新版本的darknet将images和video预测分开了，并不是很符合自己的额需求，
    因此参考darknet_images.py修改成属于自己的预测函数
注：
    darknet.py 核心函数：load_network、detect_image draw_boxes bbox2points
    darknet_images.py 核心函数： image_detection,此函数需要修改成输入图像
    darknet官方写的预测图像输出依旧为正方形，而非原图！因此要转换成原图
'''
import os
import cv2
import numpy as np
import darknet
import time

from writeXML import XMLWriter
 
class Detect:
    def __init__(self, metaPath, configPath, weightPath, gpu_id=2, batch=1):
        '''
        :param metaPath:   ***.data 存储各种参数
        :param configPath: ***.cfg  网络结构文件
        :param weightPath: ***.weights yolo的权重
        :param batch:      ########此类只支持batch=1############
        '''
        assert batch==1, "batch必须为1"
        # 设置gpu_id
        darknet.set_gpu(gpu_id)
        # 网络
        network, class_names, class_colors = darknet.load_network(
            configPath,
            metaPath,
            weightPath,
            batch_size=batch
        )
        self.network = network
        self.class_names = class_names
        self.class_colors = class_colors
        self.class_colors = {"jyz":(255,0,0),"dx_gt":(0,255,255),"gt_jyz":(255,255,0),"jyz_dx":(255,0,255)}

 
    def bbox2point(self, bbox):
        x, y, w, h = bbox
        xmin = x - (w / 2)
        xmax = x + (w / 2)
        ymin = y - (h / 2)
        ymax = y + (h / 2)
        return (xmin, ymin, xmax, ymax)
 
    def point2bbox(self, point):
        x1,y1,x2,y2 = point
        x = (x1+x2)/2
        y = (y1+y2)/2
        w = (x2-x1)
        h = (y2-y1)
        return (x,y,w,h)

    def box_point_iou(self, box1, box2):
        """
        Return intersection-over-union (Jaccard index) of box.
        Both sets of box are expected to be in (x1, y1, x2, y2) format.
        Arguments:
            box1(list)
            box2(list)
        Returns:
            iou (Tensor[N, M]): the NxM matrix containing the pairwise
                IoU values for every element in box1 and box2
        """
        xmin1, ymin1, xmax1, ymax1 = box1
        xmin2, ymin2, xmax2, ymax2 = box2
        xmin = np.maximum(xmin1, xmin2)
        ymin = np.maximum(ymin1, ymin2)
        xmax = np.minimum(xmax1, xmax2)
        ymax = np.minimum(ymax1, ymax2)
        overlap = np.maximum(0, ymax - ymin) * np.maximum(0, xmax - xmin)
        area = box_area(box1) + box_area(box2) - overlap
        iou = float(overlap) / float(area)
        return iou

    def merge_bbox_point(self, coordinates, inter_thresh=0.0):
        '''合并 area > inter_thresh 的标记框
        参数：
            coordinates: numpy.array 标记框的坐标 [[xmin,ymin,xmax,ymax],[xmin,ymin,xmax,ymax]]
            inter_thresh: 两个框的交集
        '''
        if coordinates.shape[0] == 0:
            return []
        if coordinates.shape[0] == 1:
            return coordinates

        x1 = coordinates[:, 0]
        y1 = coordinates[:, 1]
        x2 = coordinates[:, 2]
        y2 = coordinates[:, 3]
        # conf = coordinates[:, 4]
        areas = (x2 - x1 + 1) * (y2 - y1 + 1)
        order = areas.argsort()[::-1]

        while order.size > 0:
            i = order[0]
            xx1 = np.maximum(x1[i], x1[order[1:]])
            yy1 = np.maximum(y1[i], y1[order[1:]])
            xx2 = np.minimum(x2[i], x2[order[1:]])
            yy2 = np.minimum(y2[i], y2[order[1:]])

            w = np.maximum(0.0, xx2 - xx1 + 1)
            h = np.maximum(0.0, yy2 - yy1 + 1)
            inter = w * h

            inds = np.where(inter > inter_thresh)[0]
            if inds.size > 0:
                new_x1 = np.min(np.append(coordinates[i][0], coordinates[order[1:][inds]][:, 0]))
                new_y1 = np.min(np.append(coordinates[i][1], coordinates[order[1:][inds]][:, 1]))
                new_x2 = np.max(np.append(coordinates[i][2], coordinates[order[1:][inds]][:, 2]))
                new_y2 = np.max(np.append(coordinates[i][3], coordinates[order[1:][inds]][:, 3]))
                new_conf = np.max(np.append(coordinates[i][4], coordinates[order[1:][inds]][:, 4]))
                coordinates = np.delete(coordinates, np.append(order[1:][inds], i), axis=0)
                coordinates = np.vstack((coordinates, [new_x1, new_y1, new_x2, new_y2, new_conf]))
                x1 = coordinates[:, 0]
                y1 = coordinates[:, 1]
                x2 = coordinates[:, 2]
                y2 = coordinates[:, 3]
                areas = (x2 - x1 + 1) * (y2 - y1 + 1)
                order = areas.argsort()[::-1]
            else:
                order = order[1:]
        return coordinates

    def image_detection(self, image_bgr, name, network, class_names, class_colors, thresh=0.25,iou_thresh=0.5, merge=False, writexml=False):
        # 判断输入图像是否为3通道
        if len(image_bgr.shape) == 2:
            image_bgr = np.stack([image_bgr]*3, axis=-1)
        # 获取原始图像大小
        orig_h, orig_w = image_bgr.shape[:2]

        width = darknet.network_width(network)
        height = darknet.network_height(network)
        darknet_image = darknet.make_image(width, height, 3)

        # image = cv2.imread(image_path)
        image_rgb = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)
        image_resized = cv2.resize(image_rgb, (width, height), interpolation=cv2.INTER_LINEAR)

        darknet.copy_image_from_bytes(darknet_image, image_resized.tobytes())
        detections = darknet.detect_image(network, class_names, darknet_image, thresh=thresh)
        darknet.free_image(darknet_image)
        '''注意：这里原始代码依旧是608*608，而不是原图大小，因此我们需要转换'''
        new_detections = []

        if writexml:
            xmlWriter = XMLWriter(name, image_rgb.shape, len(detections))

        serial_count = 0
        if merge:
            collect_box={}
            for detection in detections:
                pred_label, pred_conf, (x, y, w, h) = detection
                new_x = x / width * orig_w
                new_y = y / height * orig_h
                new_w = w / width * orig_w
                new_h = h / height * orig_h


                (x1, y1, x2, y2) = self.bbox2point((new_x, new_y, new_w, new_h))
                if not pred_label in collect_box:
                    collect_box[pred_label] = []
                    collect_box[pred_label].append((x1, y1, x2, y2,eval(pred_conf)))
                else:
                    collect_box[pred_label].append((x1, y1, x2, y2,eval(pred_conf)))

            # print(collect_box)

            for pred_label, bboxes in collect_box.items():
                # bboxes = self.merge_bbox_point(np.array(collect_box[pred_label]), iou_thresh).tolist()
                bboxes = bboxes if pred_label == "jyz" else self.merge_bbox_point(np.array(collect_box[pred_label]), iou_thresh).tolist()
                for bbox in bboxes:
                        x1, y1, x2, y2 ,pred_conf = bbox
                        (new_x, new_y, new_w, new_h) = self.point2bbox((x1, y1, x2, y2))

                        new_detections.append((pred_label, pred_conf, (new_x, new_y, new_w, new_h)))
                        if writexml:
                            xmlWriter.addBndBox(x1, y1, x2, y2, pred_label, serial)
            # print(new_detections)

            image = darknet.draw_boxes(new_detections, image_rgb, class_colors)
            if writexml and len(detections):
                xmlWriter.save(os.path.join(save_root, "xml", name[:-4] + ".xml"))
            return cv2.cvtColor(image, cv2.COLOR_RGB2BGR), new_detections

        else:
            for detection in detections:
                pred_label, pred_conf, (x, y, w, h) = detection
                new_x = x / width * orig_w
                new_y = y / height * orig_h
                new_w = w / width * orig_w
                new_h = h / height * orig_h

                # 可以约束一下
                (x1,y1,x2,y2) = self.bbox2point((new_x, new_y, new_w, new_h))
                # x1 = x1 if x1 > 0 else 0
                # x2 = x2 if x2 < orig_w else orig_w
                # y1 = y1 if y1 > 0 else 0
                # y2 = y2 if y2 < orig_h else orig_h

                (new_x, new_y, new_w, new_h) = self.point2bbox((x1,y1,x2,y2))

                if writexml:
                    serial_count += 1
                    xmlWriter.addBndBox( x1, y1, x2, y2, pred_label, serial)
                new_detections.append((pred_label, pred_conf, (new_x, new_y, new_w, new_h)))

            image = darknet.draw_boxes(new_detections, image_rgb, class_colors)
            if writexml and len(detections):
                xmlWriter.save(os.path.join(save_root, "xml", name[:-4] + ".xml"))
            return cv2.cvtColor(image, cv2.COLOR_RGB2BGR), new_detections
 
    def predict_image(self, image_bgr, name = None, thresh=0.25, is_show=True, save_path='',iou_thresh=0.5, merge=False,writexml=False):
        '''
        :param image_bgr:  输入图像
        :param thresh:     置信度阈值
        :param is_show:   是否将画框之后的原始图像返回
        :param save_path: 画框后的保存路径, eg='/home/aaa.jpg'
        :param writexml: 是否写入xml文件，如果是，写入路径为 save_path/xml/xxx.xml
        :return:
        '''
        draw_bbox_image, detections = self.image_detection(image_bgr,name, self.network, self.class_names, self.class_colors, thresh, iou_thresh,merge,writexml)
        if is_show:
            if save_path:
                cv2.imwrite(save_path, draw_bbox_image)
            return draw_bbox_image
        return detections
 
if __name__ == '__main__':
    # # gpu 通过环境变量设置
 
    # detect = Detect(metaPath=r'/raid/ljjj/ljjj.data',
    #                 configPath=r'/raid/ljjj/ljjj_v4-tiny.cfg',
    #                 weightPath=r'/raid/ljjj/ljjj_v4-tiny_best.weights',
    #                 gpu_id=1)

    detect = Detect(metaPath=r'/raid/charlie/ljjj.data',
                    configPath=r'/raid/charlie/yolov4-tiny.cfg',
                    weightPath=r'/raid/charlie/yolov4-tiny_best.weights',
                    gpu_id=1)

    writexml = False
    merge = True
 
    # # 读取单张图像
    # image_path = r'/raid/charlie/images/2020-12-16-10-54-12.jpg'
    # image = cv2.imread(image_path, -1)
    # name = os.path.basename(image_path)
    # draw_bbox_image = detect.predict_image(image,name, save_path='./pred.jpg',merge=True,writexml=False)
 
    # # 读取文件夹
    # image_root = r'/raid/charlie/images'
    # save_root = r'/raid/charlie/result_merge'
    #
    #
    # if not os.path.exists(save_root):
    #     os.makedirs(save_root)
    #
    # if writexml and not os.path.exists(os.path.join(save_root,"xml")):
    #     os.makedirs(os.path.join(save_root,"xml"))
    #
    # for name in os.listdir(image_root):
    #     print(name)
    #     image = cv2.imread(os.path.join(image_root, name), -1)
    #     draw_bbox_image = detect.predict_image(image, name, save_path=os.path.join(save_root, name),merge=True)
 
    # 读取视频
    video_path = r'/raid/charlie/test_2.mp4'
    video_save_path = r'/raid/charlie/result_no.mp4'
    cap = cv2.VideoCapture(video_path)
    # 获取视频的fps， width height
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    print(count)
    # 创建视频
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    # fourcc = cv2.VideoWriter_fourcc('I', '4', '2', '0')
    video_writer = cv2.VideoWriter(video_save_path, fourcc=fourcc, fps=fps, frameSize=(width,height))
    ret, frame = cap.read()  # ret表示下一帧还有没有 有为True
    count ,tmp_count,tmp_fps= 0, 0, 0
    start ,tmp_start = time.time(),time.time()
    while ret:
        # 预测每一帧
        pred = detect.predict_image(frame,merge=False)
        video_writer.write(pred)
        count += 1
        tmp_count += 1
        if count % fps == 0:
            tmp_fps = tmp_fps*0.9 +tmp_count/(time.time()-tmp_start)*0.1
            print("Fps :{:.5f}  AvgFps :{:.5f}".format(tmp_fps,count/(time.time()-start)))
            tmp_count, tmp_start= 0, time.time()
        cv2.waitKey(fps)
        # 读取下一帧
        ret, frame = cap.read()
        # print(ret)
    cap.release()
    cv2.destroyAllWindows()