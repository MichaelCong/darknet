#!/usr/bin/python
# -*- coding:utf-8 -*-
from __future__ import print_function
import os, datetime, logging, time, sys, glob, requests, getpass, \
    json, socket, threading, re, serial, shutil, pickle, math, \
    base64, subprocess, signal, cv2, numpy, traceback, multiprocessing, hashlib
from multiprocessing import Process, Pool
from ctypes import *
from struct import pack, unpack
import numpy as np


plate_label = ['one_black','one_blue','one_gradient_green','one_white','one_yellow','one_yellow_green','two_green','two_white','two_yellow']


class resultTrtBox(Structure):
    _fields_ = [
        ("label", c_int),
        ("xmin", c_int),
        ("xmax", c_int),
        ("ymin", c_int),
        ("ymax", c_int),
        ("prob", c_float)]


class resultTrtBoxArray(Array):
    _type_ = resultTrtBox
    _length_ = 50


cudaVer = os.popen("nvcc -V | grep release | awk '{print $5}' | awk -F ',' '{print $1}'")
cudaVer = cudaVer.read().split("\n")[0]
opencvVer = os.popen("pkg-config opencv --modversion")
opencvVer = opencvVer.read().split("\n")[0]

libKeyVIRutiliy = cdll.LoadLibrary("/home/nvidia/tkDNN-master/libtrt.so")
trtCarInit = libKeyVIRutiliy.trtInit
trtCarUninit = libKeyVIRutiliy.trtUnInit
trtCarRecogPic = libKeyVIRutiliy.picRecog


def testPic(path):
    trtCarInit()
    img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_COLOR)
    data_ctypes_ptr = cast(img.ctypes.data, POINTER(c_char))
    res = resultTrtBoxArray()
    for i in range(1):
        recogNum = c_int(resultTrtBoxArray._length_)
        t = time.time()
        trtCarRecogPic(data_ctypes_ptr, img.shape[1], img.shape[0], pointer(recogNum), pointer(res))
        # print(i, "%.3f" % (time.time() - t), recogNum.value)
        for i in range(recogNum.value):
            print(res[i].label, res[i].prob, res[i].xmin, res[i].xmax, res[i].ymin, res[i].ymax)
    trtCarUninit()


def iou(rect1, rect2):
    rect1 = [rect1[0], rect1[1], rect1[0]+rect1[2], rect1[1]+rect1[3]]

    area_1 = (rect1[2] - rect1[0]) * (rect1[3] - rect1[1])
    area_2 = (rect2[2] - rect2[0]) * (rect2[3] - rect2[1])

    x1 = rect1[0] if rect1[0] > rect2[0] else rect2[0]
    y1 = rect1[1] if rect1[1] > rect2[1] else rect2[1]
    x2 = rect1[2] < rect2[2] and rect1[2] or rect2[2]
    y2 = rect1[3] < rect2[3] and rect1[3] or rect2[3]
    area_inter = (x2-x1)*(y2-y1)
    area_union = area_1 + area_2 - area_inter
    return area_inter*1.0 / area_union


def valRecogPath(path):
    trtCarInit()
    l_folder = os.listdir(path)
    results = []
    for i, folder in enumerate(l_folder):
        p_folder = os.path.join(path, folder)
        l_file = os.listdir(p_folder)
        allNum, trueNum, errNum, noNum, typeNum, iouNum = 0, 0, 0, 0, 0, 0
        dict_ana = {'type':folder, 'allNum':0, 'trueNum':0, 'errNum':0, 'noNum':0, 'typeNum':0, 'iouNum':0}
        for ind, file in enumerate(l_file):
            dict_ana['allNum'] += 1
            allNum += 1
            p_file = os.path.join(p_folder, file)
            plateROI = re.split(r'\[|\]', file)[1].split(',')
            plateROI = [int(float(x)) for x in plateROI]
            plateType = re.split(r'\(|\)', file)[1]

            img = cv2.imdecode(np.fromfile(p_file, dtype='uint8'), -1)
            data_ctypes_ptr = cast(img.ctypes.data, POINTER(c_char))
            obj_info = resultTrtBoxArray()
            obj_num = c_int(resultTrtBoxArray._length_)
            trtCarRecogPic(data_ctypes_ptr, img.shape[1], img.shape[0], pointer(obj_num), pointer(obj_info))
            trueFlag = False
            if obj_num.value > 0:
                for i in range(obj_num.value):
                    res_color = plate_label[obj_info[i].label]
                    res_rect = [obj_info[i].xmin, obj_info[i].ymin, obj_info[i].xmax, obj_info[i].ymax]
                    res_iou = iou(plateROI, res_rect)
                    if res_color != plateType:
                        typeNum += 1
                        dict_ana['typeNum'] += 1
                    elif res_iou < 0.7:
                        iouNum += 1
                        dict_ana['iouNum'] += 1
                    else:
                        trueFlag = True
                        trueNum += 1
                        dict_ana['trueNum'] += 1
            else:
                noNum += 1
                dict_ana['noNum'] += 1
            if not trueFlag:
                errNum += 1
                dict_ana['errNum'] += 1
            # if not trueFlag:
            #     for i in range(obj_num.value):
            #         cv2.rectangle(img, (obj_info[i].xmin, obj_info[i].ymin), (obj_info[i].xmax, obj_info[i].ymax), (0, 0, 255), 2)
            #     if not os.path.exists(os.path.dirname(p_file.replace('Validate', 'Validate-darknet'))):
            #         os.makedirs(os.path.dirname(p_file.replace('Validate', 'Validate-darknet')))
            #     cv2.imencode(".jpg", img)[1].tofile(p_file.replace('Validate', 'Validate-darknet'))
        # print("{0}, allNum={1}, trueNum={2}, errNum={3}, noNum={4}, typeNum={5}, iouNum={6}, precise={7:.3f}"\
        #   .format(folder, allNum,trueNum, errNum, noNum, typeNum, iouNum, trueNum * 1.0 / allNum))
        print(dict_ana)
        results.append(dict_ana)
    print('\n', results)
    with open('res.json', 'w') as fp:
        json.dump(results, fp)
    print("done!")
    trtCarUninit()



if __name__ == '__main__':
    print("pid:", os.getpid())

    path = '/home/nvidia/tkDNN-master/demo/0.jpg'
    testPic(path)

    # path = '/home/nvidia/crnn_ctc_plate/Data/Validate'
    # valRecogPath(path)
