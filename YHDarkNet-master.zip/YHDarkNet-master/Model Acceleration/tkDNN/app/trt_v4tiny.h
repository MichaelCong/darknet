#ifndef _TRT_V4TINY_H_
#define _TRT_V4TINY_H_





typedef struct objBoxInfo
{
    int      label;
    int      xmin;
    int      xmax;
    int      ymin;
    int      ymax;
    float    prob;
}objBoxInfo;



extern "C"
{

	int trtInit();
	int picRecog(unsigned char*data, int width, int height, int *num, objBoxInfo* res);
	int trtUnInit();

}

#endif