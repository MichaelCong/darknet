/**
    This is the core header of the library, it should be used only this
*/
#include "Network.h"
#include "Layer.h"
#include "NetworkRT.h"

#define TKDNN_VERSION 500
