#include <iostream>
#include <vector>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

#include "Yolo3Detection.h"
#include "DarknetParser.h"
#include "tkdnn.h"
#include "test.h"
#include "BoundingBox.h"



typedef struct objBoxInfo
{
    int      label;
    int      xmin;
    int      xmax;
    int      ymin;
    int      ymax;
    float    prob;
}objBoxInfo;
int picRecog(cv::Mat src, int *num, objBoxInfo* res);


tk::dnn::DetectionNN *detNN;

int main(int argc, char* argv[]){

	// init
	std::string path_net = "/home/nvidia/tkDNN-master/model/yolo4tiny_fp16.rt";
	std::string bin_path  = "/home/nvidia/tkDNN-master/model";
    std::vector<std::string> input_bins = { 
        bin_path + "/layers/input.bin"
    };
    std::vector<std::string> output_bins = {
        bin_path + "/debug/layer30_out.bin",
        bin_path + "/debug/layer37_out.bin"
    };
	std::string wgs_path  = bin_path + "/layers";
    std::string cfg_path  = bin_path + "/yolo4tiny.cfg";
    std::string name_path = bin_path + "/voc.names";

	int n_classes = 9;
	int n_batch = 1;
	
	// check for rt
	if(!fileExist(path_net.c_str())){
		std::cout<< "Wrong tensorrt file path: "<< path_net<<std::endl;		
		// 
		downloadWeightsifDoNotExist(input_bins[0], bin_path, "https://cloud.hipert.unimore.it/s/iRnc4pSqmx78gJs/download");
		// parse darknet network
		tk::dnn::Network *net = tk::dnn::darknetParser(cfg_path, wgs_path, name_path);
		net->print();
		//convert network to tensorRT
		tk::dnn::NetworkRT *netRT = new tk::dnn::NetworkRT(net, path_net.c_str());
		int ret = testInference(input_bins, output_bins, net, netRT);
		
		net->releaseLayers();
		delete net;
		delete netRT;
		
		if(!fileExist(path_net.c_str()))
		{
			std::cerr<<"TensorRT enigine build Failed!\n"<<std::endl;
			return -1;
		}else{
			std::cout<<"TensorRT enigine build Sucessfully!\n"<<std::endl;
		}
	}
	
	tk::dnn::Yolo3Detection yolo;
	detNN = &yolo;
	detNN->init(path_net, n_classes, n_batch);
	
	std::string path_file = "/home/nvidia/tkDNN-master/demo/0.jpg";
	cv::Mat img = cv::imread(path_file.c_str(), cv::IMREAD_COLOR);
	if(!img.data){
		std::cerr<<"read image failed!"<<std::endl;
		return -1;
	}
	
	int num = 50;
	objBoxInfo res[num];
	for(int i = 0; i < 100; i++){
		time_t t0 = clock();
		picRecog(img, &num, res);
		time_t t1 = clock();
		std::cout<<"["<< i <<"]:time spend "<<(double)(t1 - t0)/CLOCKS_PER_SEC <<std::endl;
	}
	
	cv::rectangle(img, cv::Point(res[0].xmin,res[0].ymin), cv::Point(res[0].xmax, res[0].ymax), cv::Scalar(255, 0, 0), 2);
	cv::imwrite("dst.jpg", img);
	
	
	return 0;
}



int picRecog(cv::Mat src, int *num, objBoxInfo* res){
	
	std::vector<cv::Mat> batch_dnn_input;
	std::vector<tk::dnn::box> detected_bbox;
	//inference 
	detected_bbox.clear();
	batch_dnn_input.push_back(src);
	detNN->update(batch_dnn_input, 1);
	// detNN->draw(batch_frames);
	detected_bbox = detNN->detected;

	int cnt = 0;
	for(auto d:detected_bbox){
		res[cnt].label = d.cl;
		res[cnt].prob = d.prob;
		res[cnt].xmin = d.x;
		res[cnt].ymin = d.y;
		res[cnt].xmax = d.x + d.w;
		res[cnt].ymax = d.y + d.h;		
		cnt++;
	}	
	*num = cnt;

	return 0;
}


