#!/bin/bash
echo "1.Start Export DarkNet ......"
cd darknet_export 
make -j7

cfg_name=$1
weights_name=$2
echo "模型输入路径：${cfg_name}"
echo "权重输入路径：${weights_name}"

rm -rf layers/ debug/
mkdir layers debug

./darknet export ${cfg_name} ${weights_name} layers

echo "2.Start Complie tkDnn ......"
cd ../tkDNN
mkdir build
cd build
cmake .. -DDEBUG=True
make -j7

echo "3.Start Run tkDnn Vs TensorRT......"
rm -rf yolo4tiny_custom
mkdir yolo4tiny_custom
cd yolo4tiny_custom
cp -r ../../../darknet_export/layers ../../../darknet_export/debug ./
cd ..
rm -rf yolo4tiny_custom_fp32.rt
./test_yolo4tiny_custom

echo "4.Run Model yolo4tiny Acceleration......"
./demo yolo4tiny_custom_fp32.rt /home/nvidia/rencong/tkDNN/build/TX2result.avi



